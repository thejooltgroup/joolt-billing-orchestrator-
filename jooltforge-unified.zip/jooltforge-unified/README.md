# jooltforge (unified)

Single Vercel project that replaces `jooltforge`, `jooltforge-app`, `jooltforge-delivery`, and `jooltforge-tpl`.

## Structure

- `/` → landing page (sells Bundle $497, Custom GPT Build $197, Setup $750)
- `/app` → the GPT builder tool
- `/thanks` → post-purchase delivery page (Bundle buyers)
- `/intake` → intake form (Custom GPT Build / Setup buyers)
- `/api/templates` → templates JSON (rewritten to /templates.json)
- `/templates.json` → 500-template library

## Deploy

Two options:

**A. Vercel CLI (fastest if you have it):**
```
cd jooltforge-unified
vercel --prod
```
When it asks which project, pick the existing `jooltforge` project so the site lands at `jooltforge.vercel.app`.

**B. Vercel dashboard (drag-and-drop):**
1. Zip the contents of this folder.
2. Vercel dashboard → `jooltforge` project → Deployments → three-dot menu → "Deploy via CLI" or import.
   (Vercel's UI doesn't have drag-drop for existing projects — CLI is the actual path here.)

## After it deploys, update Stripe redirects

The 3 payment links currently point to `jooltforge-delivery.vercel.app/...`. Update to:
- Bundle → `https://jooltforge.vercel.app/thanks?session_id={CHECKOUT_SESSION_ID}`
- Custom GPT Build → `https://jooltforge.vercel.app/intake?session_id={CHECKOUT_SESSION_ID}`
- Setup Consulting → `https://jooltforge.vercel.app/intake?session_id={CHECKOUT_SESSION_ID}`

## Then delete these Vercel projects
- jooltforge-app
- jooltforge-delivery
- jooltforge-tpl
- jooltforge-v4
- jooltforge-site
- jooltforge-chamber
